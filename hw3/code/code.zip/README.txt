1) Compile each "problem___.cpp" file with potentials.cpp
3) Change params if desired
4) Compile and run
5) Go to problem___.m in matlab and run