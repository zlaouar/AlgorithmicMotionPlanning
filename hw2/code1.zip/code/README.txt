ASEN 5519 HW 2 README

Problem 5: Files include problem5.cpp, cobstacle.cpp, problem5.m
	1) To change obstacle vertices, navigate to line 12 of problem5.cpp and enter desired obstacle.
	2) To change rotation angle navigate to line 14.
	2) To compile and run, open a terminal and enter: g++ -o problem5 problem5.cpp cobstacle.cpp, and then 	run: ./problem5.exe
	3) This will generate 2 csv files in the current folder which the problem5.m file will use.
	4) Open MATLAB and navigate to the current folder and run problem5.m to view the plots and outputs

Problem 7: 
	1) Open MATLAB, Open MATLAB and navigate to the current folder and run 	problem7.m to view the plots and outputs

Problem 8: Files include problem5.cpp, cobstacle.cpp, problem5.m
	1) To specify the length of each link, number of obstacles, and vertices of each obstacle, open problem8.cpp and change the respective parameters
	2) To compile and run, open a terminal and enter: g++ -o problem8 problem8.cpp cobstacle.cpp, and then 	run: ./problem8.exe
	3) This will generate 3 csv files in the current folder which the problem8.m file will use.
	4) Open MATLAB and navigate to the current folder and run problem8.m to view the plots and outputs


