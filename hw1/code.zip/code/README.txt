1) Go to Bug1.cpp or Bug2.cpp
2) Go to main function and find motionPlan(obstacles_map1, start_map1, goal_map1, scale_factor_map1);
3) Change params if desired
4) Compile and run
5) Go to problem7.m in matlab and run